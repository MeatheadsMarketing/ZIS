```mermaid
graph TD
    classDef level1 fill:#f9f,stroke:#333,stroke-width:2px;
    classDef level2 fill:#bbf,stroke:#333,stroke-width:2px;
    classDef level3 fill:#bfb,stroke:#333,stroke-width:2px;
    classDef level4 fill:#fbf,stroke:#333,stroke-width:2px;
    classDef level5 fill:#ffb,stroke:#333,stroke-width:2px;
```
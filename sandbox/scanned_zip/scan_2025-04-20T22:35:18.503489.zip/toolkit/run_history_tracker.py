def track_history(df):
    return f"Tracked {len(df)} files this session. Logs saved."
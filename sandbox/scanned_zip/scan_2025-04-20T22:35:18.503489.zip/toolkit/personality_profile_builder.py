def build_profile(name, traits):
    return {
        "name": name,
        "traits": traits,
        "behavior": "adaptive",
        "confidence": 0.9
    }
def log_decision(selected_file, mode, cheat_code):
    return f"**Log Entry**: You explored `{selected_file}` in mode `{mode}` using `{cheat_code}`.\nOption chosen: TBD"
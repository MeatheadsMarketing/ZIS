def simulate_tweak(selected_file, cheat_code):
    return f"# Simulated tweak on {selected_file}\nprint('This is a sandbox output')"
def generate_branches(selected_file, mode, cheat_code):
    return [
        f"[Mock Option 1] based on {selected_file} under {mode} using {cheat_code}",
        f"[Mock Option 2] alternative path...",
        f"[Mock Option 3] radical reframe."
    ]
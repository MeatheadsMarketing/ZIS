def dispatch_command(agent, command):
    return {
        "agent": agent,
        "command": command,
        "dispatched": True
    }
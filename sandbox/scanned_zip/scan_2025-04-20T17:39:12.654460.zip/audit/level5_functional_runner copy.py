import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from config.keychain_loader import load_keychain

print("🚀 Level 5 Audit – Functional Flow Test")

# Init for module

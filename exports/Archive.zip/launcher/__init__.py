# Launcher module init

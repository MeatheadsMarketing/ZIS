# Outputs module init


import streamlit as st
import os
import openai
import pandas as pd

from gpt_logic_evaluator import set_api_key, gpt_analyze_script

REGISTRY_PATH = "registry/component_registry.csv"

def readme_generator_tab():
    st.title("📝 README Generator")
    st.caption("Auto-generate assistant documentation using GPT from component registry.")

    if not os.path.exists(REGISTRY_PATH):
        st.warning("Registry not found.")
        return

    df = pd.read_csv(REGISTRY_PATH)
    if "GPT_Notes" not in df.columns:
        st.error("No GPT_Notes column found. Please run GPT tagging first.")
        return

    bundles = df["Origin"].dropna().unique()
    selected_bundle = st.selectbox("Choose Assistant Group", bundles)

    subset = df[df["Origin"] == selected_bundle]
    notes = "\n".join(subset["GPT_Notes"].dropna().tolist())

    if st.button("📄 Generate README via GPT"):
        set_api_key()
        prompt = f"""You are a developer assistant. Generate a README.md for an assistant pack named `{selected_bundle}`. Include:
- Purpose
- What it includes
- Tags
- Roles
- GPT-generated summary
Based on these GPT notes:
{notes}
"""
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a tool documentation assistant."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3
        )
        summary = response['choices'][0]['message']['content']
        st.markdown("### 📄 README.md")
        st.code(summary, language="markdown")

        with open(f"exports/{selected_bundle}_README.md", "w") as f:
            f.write(summary)
        st.success(f"Saved to `exports/{selected_bundle}_README.md`")

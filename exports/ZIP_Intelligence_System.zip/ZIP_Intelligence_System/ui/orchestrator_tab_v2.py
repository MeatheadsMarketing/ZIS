
import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import streamlit as st
import openai
import zipfile
import shutil
from pathlib import Path
from gpt_recovery_flow_engine import recover_and_register, export_tool_zip
from gpt_logic_evaluator import set_api_key

def orchestrator_tab():
    st.title("🧠 GPT Orchestrator v2")
    st.caption("Drop a ZIP, let GPT analyze, and take guided recovery actions.")

    scan_dir = "sandbox/orchestrator_scan"
    uploaded = st.file_uploader("Upload ZIP", type="zip")

    if uploaded:
        if os.path.exists(scan_dir):
            shutil.rmtree(scan_dir)
        os.makedirs(scan_dir, exist_ok=True)

        with open(os.path.join(scan_dir, uploaded.name), "wb") as f:
            f.write(uploaded.read())

        with zipfile.ZipFile(os.path.join(scan_dir, uploaded.name), "r") as z:
            z.extractall(scan_dir)

        py_files = list(Path(scan_dir).rglob("*.py"))
        recovered_files = [f.name for f in py_files]
        sample = ""
        for f in py_files:
            code = f.read_text(encoding="utf-8", errors="ignore")
            if len(code) > 40:
                sample = code[:3000]
                break

        if sample:
            set_api_key()
            st.markdown("### 🧠 GPT Recovery Plan")
            with st.spinner("Analyzing..."):
                response = openai.ChatCompletion.create(
                    model="gpt-4",
                    messages=[
                        {"role": "system", "content": "You are a recovery planner."},
                        {"role": "user", "content": f"Analyze the code and recommend 3 actions:\n{sample}"}
                    ]
                )
                gpt_summary = response["choices"][0]["message"]["content"]
                st.success(gpt_summary)

            selected_action = st.selectbox("Choose Action", [
                "Run GPT Tags + Register", "Export Tools to ZIP", "Add Shortcut Triggers"
            ])
            selected_files = st.multiselect("Select Tools", recovered_files)

            if st.button("✅ Execute"):
                results = []
                if selected_action == "Run GPT Tags + Register":
                    for tool in selected_files:
                        results.append(recover_and_register(tool, category="Orchestrated"))
                elif selected_action == "Export Tools to ZIP":
                    results.append(export_tool_zip(selected_files, pack_name="OrchestratedPack"))
                elif selected_action == "Add Shortcut Triggers":
                    results = [f"📎 Shortcut for `{tool}` simulated." for tool in selected_files]

                for r in results:
                    st.success(r)
        else:
            st.warning("No usable .py files found.")

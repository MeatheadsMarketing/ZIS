
import streamlit as st
import pandas as pd
import os
import openai
import shutil

from gpt_logic_evaluator import set_api_key, gpt_analyze_script

REGISTRY_PATH = "registry/component_registry.csv"

def assistant_pack_builder_tab():
    st.title("📦 Assistant Pack Builder")
    st.caption("Group recovered tools into reusable assistant packs with GPT-enhanced grouping.")

    if not os.path.exists(REGISTRY_PATH):
        st.warning("No registry file found.")
        return

    df = pd.read_csv(REGISTRY_PATH)
    ready_tools = df[df["Status"] == "Launch-Ready"]
    if ready_tools.empty:
        st.info("No tools marked as launch-ready.")
        return

    pack_name = st.text_input("Assistant Pack Name", placeholder="AuditCommander, PromptPack, etc.")
    selected = st.multiselect("Select tools to include", ready_tools["Component"].tolist())

    if st.button("💡 GPT Suggest Pack Structure"):
        sample_notes = "\n".join(ready_tools["GPT_Notes"].fillna("").head(3))
        set_api_key()
        gpt_out = gpt_analyze_script(sample_notes)
        st.markdown("### GPT Suggestions:")
        st.info(gpt_out)

    if st.button("📦 Build Assistant Pack Folder"):
        export_path = f"exports/{pack_name}"
        os.makedirs(export_path, exist_ok=True)
        for file in selected:
            found = False
            for root, _, files in os.walk("RecoveredTools_Library_Categorized"):
                if file in files:
                    shutil.copy(os.path.join(root, file), os.path.join(export_path, file))
                    found = True
                    break
            if not found:
                st.warning(f"{file} not found in RecoveredTools_Library.")
        st.success(f"Assistant pack `{pack_name}` created with {len(selected)} files.")

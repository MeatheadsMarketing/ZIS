# 📁 ZIP Intelligence System Folder Structure

- `launcher/`: Launcher module
- `scanner/`: Scanner module
- `engines/`: Engines module
- `ui/`: Ui module
- `outputs/`: Outputs module
- `sandbox/`: Sandbox module
- `config/`: Config module
- `docs/`: Docs module
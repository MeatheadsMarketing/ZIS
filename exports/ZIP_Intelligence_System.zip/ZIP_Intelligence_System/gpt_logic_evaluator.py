
import openai
import os

def set_api_key(key=None):
    if key:
        openai.api_key = key
    else:
        openai.api_key = os.getenv("OPENAI_API_KEY")

def gpt_analyze_script(code_str, model="gpt-4"):
    messages = [
        {"role": "system", "content": "You are an AI assistant recovery agent that audits code for assistant system integration."},
        {"role": "user", "content": f"""Analyze the following script and answer:

1. What does it do?
2. What system role should it be assigned (e.g. Planner, Cleaner, Trigger, PromptEngine, Tab)?
3. Is it ready to launch (yes/no)?
4. Suggest a tag or shortcut name for registration.

SCRIPT:
{code_str}
"""}
    ]
    try:
        response = openai.ChatCompletion.create(
            model=model,
            messages=messages,
            temperature=0.3
        )
        return response['choices'][0]['message']['content']
    except Exception as e:
        return f"[GPT ERROR] {e}"

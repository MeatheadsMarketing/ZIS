# Registry module init

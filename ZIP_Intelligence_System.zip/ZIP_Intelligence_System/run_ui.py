
import os
os.system("streamlit run launcher/main_app.py")

# Shortcut module init

# file_viewer_previewer.py — Live Streamlit Applet

import streamlit as st
st.title('File Viewer Previewer')
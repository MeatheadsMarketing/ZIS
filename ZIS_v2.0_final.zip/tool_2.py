# tool_2.py
print('This is tool_2.py')